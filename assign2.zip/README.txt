
func Module

This Python module, func.py, provides a collection of simple utility functions 
for basic mathematical and string operations.

Functions:
1. average(a, b)
   - Calculates the average of two numbers.
   - Example: average(10, 20) => 15.0

2. fourth_power(x)
   - Returns the fourth power of a number.
   - Example: fourth_power(2) => 16

3. format_name(first, last)
   - Capitalizes and formats a full name properly.
   - Example: format_name(" john", "DOE ") => "John Doe"

Usage:
1. Upload func.py to your Colab session.
2. Import it using: import func
3. Call the functions like: func.average(5, 10)

Created for Assignment 2: Functions and Module Creation.
