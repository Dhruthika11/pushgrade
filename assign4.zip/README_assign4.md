
# 📝 Assignment 4: File Handling and JSON Operations in Python

This assignment demonstrates the use of file operations and JSON serialization/deserialization in Python. The script performs a series of tasks to create, read, append, and manipulate text and JSON files.

---

## 📂 Tasks Covered

###  Task 1: Create and Write to a File
- Creates a file named `example.txt`
- Writes multiple lines of text to it using a `with open()` block and `write()`
- Exception handling ensures errors (like permission issues) are caught

### Task 2: Read from a File
- Reads the entire content of `example.txt` using `read()`
- Uses exception handling to manage missing file errors

### Task 3: Append to the File
- Appends a new line to the same file (`example.txt`)
- Reads and prints the updated content afterward

### Task 4: Serialize and Deserialize JSON
- A dictionary containing user data is serialized into a JSON file named `data.json`
- The JSON file is then read back and deserialized into a Python dictionary
- Uses `json.dump()` and `json.load()` with exception handling

---

##  Requirements

This script uses standard Python libraries:
- `json`

No external packages are required.

---

##  How to Run

You can run the script in any Python 3 environment:

### Option 1: Run Locally
Save the script as `assign4.py` and run:
```bash
python assign4.py
```

### Option 2: Run in Google Colab
1. Copy the code into a new Colab notebook.
2. Execute each cell in order.

---

##  Notes

- Running this script will create two files in the current working directory:
  - `example.txt` – A text file containing written and appended lines.
  - `data.json` – A JSON file with user profile data.
- File handling includes proper error management using `try-except`.

---

##  Sample Output

```
Data written successfully.
File contents:
Hello, this is the file i created .
Idk what to write.

Data appended successfully.
File contents:
Hello, this is the file i created .
Idk what to write.
This is an appended line.

Data serialized to JSON file.
Deserialized JSON data:
{'name': 'Alice', 'age': 30, 'hobbies': ['reading', 'cycling', 'coding']}
```

---
