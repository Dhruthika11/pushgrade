
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class QueueLinkedList:
    def __init__(self):
        self.front_node = None
        self.rear_node = None

    def enqueue(self, data):
        new_node = Node(data)
        if not self.rear_node:
            self.front_node = self.rear_node = new_node
        else:
            self.rear_node.next = new_node
            self.rear_node = new_node

    def dequeue(self):
        if self.front_node:
            data = self.front_node.data
            self.front_node = self.front_node.next
            if not self.front_node:
                self.rear_node = None
            return data

    def front(self):
        if self.front_node:
            return self.front_node.data
