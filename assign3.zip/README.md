
# Data Structures Implementation - Campus Connect IIT Gandhinagar

This repository contains implementations of various fundamental data structures using Python. The following data structures are implemented:

- Dynamic Array
- Singly Linked List
- Doubly Linked List
- Stack (Array-based and Linked List-based)
- Queue (Array-based and Linked List-based)
- Binary Tree
- Graph (Adjacency List-based)

## Prerequisites

Before you begin, ensure that you have the following installed on your system:

- **Python 3.x**: You can download Python from the [official website](https://www.python.org/downloads/).

You can check if Python is installed by running:
```bash
python --version
```

If it's not installed, you can follow the installation guide from the official website.

## Directory Structure

The repository contains the following files:

- `dynamic_array.py`: Implementation of a dynamic array with insert, delete, and access methods.
- `extended_linked_list.py`: Implementation of both singly and doubly linked lists with insertion, deletion, and traversal methods.
- `stack_array.py`: Stack implementation using arrays.
- `stack_linked_list.py`: Stack implementation using linked lists.
- `queue_array.py`: Queue implementation using arrays.
- `queue_linked_list.py`: Queue implementation using linked lists.
- `binary_tree.py`: Binary tree implementation with insertion and traversal methods.
- `graph_adj_list.py`: Graph implementation using an adjacency list representation with DFS and BFS methods.
- `README.md`: This file.

## How to Run the Code

1. **Clone the Repository (Optional)**
   If you prefer to work locally, you can clone the repository by running:
   ```bash
   git clone <repository_url>
   ```

2. **Navigate to the Folder**
   Ensure you are in the directory where the Python files are located. For example:
   ```bash
   cd /path/to/directory
   ```

3. **Run Individual Scripts**
   You can run any Python file directly using the Python interpreter. For example, to test the **Dynamic Array** implementation:
   ```bash
   python dynamic_array.py
   ```

   Similarly, to test any other data structure implementation, replace `dynamic_array.py` with the respective file name.

4. **Test Cases**
   Each Python file contains test cases. When you run the file, the test cases will automatically be executed, and the output will be printed in the terminal.

5. **Modifications**
   Feel free to modify the code, add more test cases, or extend the functionality as needed.

## Explanation of Code

### Dynamic Array
Implements a dynamic array with:
- `insert(index, value)`
- `delete(index)`
- `access(index)`

### Singly and Doubly Linked Lists
- Singly Linked List: insert, delete, traverse.
- Doubly Linked List: insert/delete at both ends, traverse forward/backward.

### Stack
Array-based and linked list-based implementations:
- `push(value)`
- `pop()`
- `peek()`

### Queue
Array-based and linked list-based implementations:
- `enqueue(value)`
- `dequeue()`
- `front()`

### Binary Tree
Binary tree with:
- `insert(value)`
- In-order, Pre-order, and Post-order traversals

### Graph (Adjacency List)
Graph with:
- `add_vertex(vertex)`
- `add_edge(vertex1, vertex2)`
- `dfs(start)`
- `bfs(start)`

## Example Output

Example output from `binary_tree.py`:
```
In-order traversal: [5, 10, 15, 20]
Pre-order traversal: [10, 5, 15, 20]
Post-order traversal: [5, 15, 20, 10]
```

