
class DynamicArray:
    def __init__(self):
        self.array = []
    
    def insert(self, index, value):
        self.array.insert(index, value)
    
    def delete(self, index):
        if 0 <= index < len(self.array):
            self.array.pop(index)
    
    def access(self, index):
        if 0 <= index < len(self.array):
            return self.array[index]
        return None
