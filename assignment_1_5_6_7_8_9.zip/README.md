
# 🐍 Python Assignment Series (1, 5, 6, 7, 8, 9)

This repository contains a consolidated Python script that demonstrates core programming concepts across multiple assignments. It covers foundational syntax, object-oriented programming, exception handling, functional programming, data manipulation, visualization, and testing using `unittest`.

---

## 📂 File Included

- `assignment_1_5_6_7_8_9.py`  
  A single Python script that contains solutions to assignments 1, 5, 6, 7, 8, and 9. Each section is clearly marked with comments.

---

## 🚀 How to Run

### 📌 Option 1: Google Colab / Jupyter Notebook
1. Open Google Colab or Jupyter Notebook.
2. Upload or copy the script content.
3. Run all cells (Ctrl+F9 or Run All).

### 📌 Option 2: Local Python
1. Make sure you have Python 3 installed.
2. Install dependencies if needed:
   ```bash
   pip install matplotlib pandas numpy
   ```
3. Run the script:
   ```bash
   python assignment_1_5_6_7_8_9.py
   ```

---

## 🧰 Requirements

This script uses the following libraries:

- `matplotlib` – for plots and heatmaps
- `pandas` – for dataframes and merging
- `numpy` – for statistical and matrix operations
- `unittest` – for testing

Install any missing ones with:
```bash
pip install matplotlib pandas numpy
```

---

## 📘 Topics Covered

### ✅ Assignment 1 – Python Syntax and Data Types
- Numbers, strings, lists, tuples, dictionaries
- String operations, slicing, joining, replacing
- Conditional logic and loops

### ✅ Assignment 5 – Exception Handling
- Try/Except/Else/Finally
- Custom exception: `InsufficientFundsError`
- File I/O with logging

### ✅ Assignment 6 – Object-Oriented Programming
- `Book` class with borrow/return functionality
- Object instantiation and method demonstration

### ✅ Assignment 7 – Advanced Functions & Comprehensions
- Higher-order functions
- Lambda, decorators
- List, dictionary, and set comprehensions

### ✅ Assignment 8 – Data Visualization
- Multi-line plots
- Heatmaps using `imshow()`
- Colorbars, labels, and subplot formatting

### ✅ Assignment 9 – NumPy, Pandas, and Testing
- Data analysis with `numpy`
- Data merging with `pandas`
- Unit & integration tests with `unittest`

---

## 📌 Notes

- Some sections (temperature conversion, withdrawal) use `input()`, which will pause execution waiting for user input.
- A file `temperature_log.txt` will be created/appended to in the temperature conversion section.
- GUI windows are **not included**—all output is in the console or matplotlib graphs.
- Plots will appear in a new window or inline if using Jupyter/Colab.
- Tests are auto-executed at the end of the file using `unittest.main()`.

---

## 🖥️ Sample Output

```
Positive number
<class 'int'>
<class 'float'>
<class 'complex'>

String Operations:
AARAV
aarav
5
I
r
a student
Hi! Hi! Hi!
['I', 'am', 'a', 'student', 'at', 'IIT', 'Gandhinagar', 'in', 'Gujarat']
...

Calling function 'multiply' with arguments (3, 4)
Function 'multiply' returned 12
['A', 'B', 'C', 'D']
{'apple': 1.1, 'banana': 0.55, 'cherry': 2.2}
{'a', 'e', 'i', 'o', 'u'}

...
test_average (__main__.TestFunctions) ... ok
test_combined_usage (__main__.TestFunctions) ... ok
test_format_name (__main__.TestFunctions) ... ok
test_fourth_power (__main__.TestFunctions) ... ok
```

---

## 🧪 Tests Included

All major functions (`average`, `fourth_power`, `format_name`) are tested, including an **integration test** that combines them. Tests run automatically at the end using `unittest`.
